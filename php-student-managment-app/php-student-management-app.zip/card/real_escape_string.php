<?php 
include 'conn.php';
if (isset($_POST['submit'])) {
	$name = $conn->real_escape_string($_POST['name']);
	$password =$conn->real_escape_string($_POST['pwd']);
	echo $name."<br>";
	echo $password;
}

 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<title>Php real_escape_string Function</title>
 </head>
 <body>
 	<form action="real_escape_string.php" method="POST">
 		<input type="text" placeholder="Name" name="name"><input type="text" placeholder="password" name="pwd">
 		<br>
 		<input type="submit" value="Submit" name="submit">
 	</form>
 </body>
 </html>