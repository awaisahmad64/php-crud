<?php 
include 'conn.php';
if(isset($_GET['update']))
{
  $id=$_GET['update'];
$sql = "select * from student where id=$id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Student Management System | Dashboad</title>
  <link rel="stylesheet" href="custom.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="font/all.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="icheck-bootstrap/icheck-bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="bs-custom-file-input/bs-custom-file-input.min.js"></script>
</head>
<body>
  <header>
    <div class="user-name float-right mt-2 pr-2">
        <h6><img src="awais.jpg" class="rounded-circle ml-2" height="50px" width="50px"> Awais Sandhu</h6>
      </div>
  </header>
  <section>
    <nav>
      <div class="brand-name">
        <h4 class="text-white text-center">Webx Solutions</h4>
      </div>
      <div class="user-name">
        <h6><img src="awais.jpg" class="rounded-circle ml-2" height="50px" width="50px"> Awais Sandhu</h6>
      </div>
      <ul>
        <li><a href="dashboard.php"><i class="fas fa-th mr-2"></i>DashBoard</a></li>
        <li><a href="student.php"><i class="fas fa-users mr-2"></i>Students</a></li>
        <li><a href="teacher.php"><i class="fas fa-user-tie mr-2"></i>Teachers</a></li>
        <li><a href="#"><i class="fas fa-book-reader mr-2"></i>Courses</a></li>
      </ul>
    </nav>
    <aside>
      <div class="header">
      </div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <a href="addstudent.php" class="btn btn-primary my-2" id="bg-custom"><i class="fas fa-plus mr-2"></i></i>Add Student</a>
        <div class="card card-primary">
          <div class="card-header" id="bg-custom">
            <h3 class="card-title text-white">Students</h3>
          </div>
            <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                 <img class="rounded-circle d-block mx-auto" src="uploads/<?php echo $row['image'] ?>" alt="Student image" height="200px" width="200px">
              </div>
           </div>
              <form role="form" action="update.php" method="POST" enctype="multipart/form-data">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6 ">
                  <div class="form-group">
               <label for="Student_id">Student ID</label>
               <input type="text" value="<?php echo $row['id'] ?>" name="id" class="form-control" >
              </div>
              <div class="form-group">
               <label for="Father Name">Father Name</label>
               <input type="text" name="fathername" value="<?php echo $row['fathername'] ?>" name="name" class="form-control">
              </div>
              <div class="form-group">
               <label for="User Name">User Name</label>
               <input type="text" name="username" value="<?php echo $row['username'] ?>" class="form-control" >
              </div>
              <div class="form-group">
               <label for="gender">Gender</label>
               <input type="text" name="gender" value="<?php echo $row['gender'] ?>" class="form-control" >
              </div>
                </div><!--col-md-6 ended-->
                <div class="col-md-6">
                   <div class="form-group">
               <label for="Name">Name</label>
               <input type="text" name="name"  value="<?php echo $row['name'] ?>" class="form-control" >
              </div>
              <div class="form-group">
               <label for="email">Email</label>
               <input type="text" name="email" value="<?php echo $row['email'] ?>"  class="form-control" >
              </div>
               <div class="form-group">
               <label for="password">Password</label>
               <input type="text" name="password" value="<?php echo $row['password'] ?>"  class="form-control" >
              </div>

               <div class="form-group">
               <label for="Address">Address</label>
               <input type="text" name="address" value="<?php echo $row['address'] ?>"  class="form-control">
              </div>
              <div class="form-group">
                <label for="photo">Photo</label>
                 <input type="file" name="image" class="form-control">
              </div>
                </div><!--col-md-6 ended-->
                <div class="form-group">
                 <input type="submit" id="bg-custom" name="update1" class="form-control btn btn-primary">
              </div>
              </div>
            </div>
             <?php } ?>
          </form>
  </div>
</div>
    </aside>
  </section>
</body>
</html>