<?php
include 'conn.php';
if (isset($_GET['msg'])) {
# code...
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Student Management System | Dashboad</title>
    <link rel="stylesheet" href="custom.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="font/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="icheck-bootstrap/icheck-bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="bs-custom-file-input/bs-custom-file-input.min.js"></script>
  </head>
  <body>
    <div class="row">
      <div class="col-md-6 offset-3">
        <div class="card card-primary mt-5">
          <div class="card-header" id="bg-custom">
            <h3 class="card-title text-white text-center">Login</h3>
          </div>
          <form role="form" action="login.php" method="POST" enctype="multipart/form-data">
            <div class="card-body">
              <div class="form-group">
                <label for="User Name">User Name</label>
                <input type="text" name="username" placeholder="User Name" class="form-control">
              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" placeholder="password" class="form-control">
              </div>
              
              <div class="form-group">
                <input type="submit" id="bg-custom" name="login" class="form-control btn btn-primary">
              </div>
              <a href="forgot.php">Forgot password?</a>
            </div>
          </form>
          <p class="text-center text-danger"><?php
            include 'conn.php';
            if (isset($_GET['msg'])) {
            echo $_GET['msg'];
            }
          ?> </p>
        </div>
      </div>
    </div>
  </body>
</html>