<?php
include 'conn.php';
if(isset($_GET['token']))
{
$token =$_GET['token'];
$newpwd=$_POST['newpwd'];
$cpwd=$_POST['cpwd'];
echo $newpwd;
echo $cpwd;
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Student Management System | Dashboad</title>
		<link rel="stylesheet" href="custom.css">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="font/all.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="icheck-bootstrap/icheck-bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="bs-custom-file-input/bs-custom-file-input.min.js"></script>
	</head>
	<body>
		<div class="row">
			<div class="col-md-6 offset-3">
				<!-----------------------
				<div class="alert alert-success">
					//<p><?php// if (isset($_GET['msg1'])) {
							//$msg1=$_GET//['msg1'];
							// echo "<strong>Success! </strong>".$msg1;
							//}elseif(isset($_GET['msg2'])) {
							// $msg2=$_GET//['msg2'];
					// echo "<strong>Failed! </strong>".$msg2; }  ?></p> </div>
					--------------------->
					<div class="card card-primary mt-5">
						<div class="card-header" id="bg-custom">
							<h3 class="card-title text-white text-center">Password Reset</h3>
						</div>
						<form role="form" action="forgot1.php" method="POST">
							<div class="card-body">
								<div class="form-group">
									<label for="Email">New password</label>
									<input type="text" name="newpwd" placeholder="New password" class="form-control">
								</div>
								<div class="form-group">
									<label for="Email">Confirm Password</label>
									<input type="text" name="cpwd" placeholder="Confirm password" class="form-control">
								</div>
								
								<div class="form-group">
									<input type="submit" id="bg-custom" name="forgot" class="form-control btn btn-primary" value="SEND CODE TO EMAIL">
								</div>
								<a href="index.php">Have account? Log in</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</body>
	</html>