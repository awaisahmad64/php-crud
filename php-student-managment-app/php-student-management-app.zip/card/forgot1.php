<?php
include 'conn.php';
if(isset($_POST['forgot']))
{
$email= $_POST['email'];
$sql = "select * from student  where email='$email'";
$result = $conn->query($sql);
$emailCheck =$result->num_rows;
if(!$result)
{
echo "Due to error query is  not fire";
}
else{
if($emailCheck){
	$token=rand(10,100);
	$token=password_hash($token,PASSWORD_BCRYPT);
	require 'phpmailer/PHPMailerAutoload.php';
$mail = new PHPMailer;
$mail->SMTPDebug = 0;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'thewebxsolutions@gmail.com';                 // SMTP username
$mail->Password = '$Sandhubu6412';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to
$mail->setFrom('thewebxsolutions@gmail.com', 'Webx Solutions');
$mail->addAddress($email, 'Awais Sandhu');     // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
//$mail->addReplyTo('info@example.com', 'Information');
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');
//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML
$mail->Subject = 'Password Resset';
$mail->Body    = 'Plese Click on this link to activate your password http://localhost/card/passwordUpdate.php?token=$token'.$token;
//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
if(!$mail->send()) {
$msg2="email address";
header("Location:forgot.php?msg2=".$msg2);
echo 'Mailer Error: ' . $mail->ErrorInfo;
}
else {
$msg1="Code Sent.Check your Email";
header("Location:forgot.php?msg1=".$msg1);
}
}
else{
$msg2="Wrong Email";
header("Location:forgot.php?msg2=".$msg2);
}
}
}
?>