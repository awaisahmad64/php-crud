<?php 
include 'conn.php';
if(isset($_POST['login']))
{ 
$username =$_POST['username'];
$password =$_POST['password'];

$sql = "select username, password from student  where username='$username' or password='$password'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
  if($username ===$row['username'] && $password===$row['password']){
  	header("Location:dashboard.php");
  }
  else{

  	if($username != $row['username'])
  	{
  	$msg= "Please enter correct name";
  	header("Location:index.php?msg=".$msg);
    }
    else
    {
    	$msg= "Please enter correct password";
  	    header("Location:index.php?msg=".$msg);
    }
  }
}
#$name =$_POST['name'];
#$fname =$_POST['fathername'];
#$address =$_POST['address'];
#$gender =$_POST['gender'];
#$fileName = $_FILES['image']['name'];
#$fileType = $_FILES['image']['type'];
#$fileSize = $_FILES['image']['size'];
#$fileTmpLoc = $_FILES['image']['tmp_name'];
#$fileStore = "uploads/".$fileName;
#move_uploaded_file($fileTmpLoc,$fileStore);
#$sql="insert into student(name,fathername,gender,username,password,email,address,image) values('$name','$fname','$gender','$username','$password','$email ','$address','$fileName')";
#if($conn->query($sql)){
	#echo "Record has been inserted successfull!";
	#header("Location:student.php");
#}

?>