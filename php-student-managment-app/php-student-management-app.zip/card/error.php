<?php
$serverName ="localhost";
$userName = "root";
$password ="";
$mydb ="MinSchool";
$conn = new mysqli($serverName, $userName, $password, $mydb);
if(!$conn){
	die("connection failed".$conn->connect_error);
}
$email="awais6412l@gmail.com";
$sql = "select email from student  where email='$email'";
$result = $conn->query($sql);
//$row = $result->fetch_assoc();
$yes=$result->num_rows;
if($yes)
{
	echo "Email is exist".$yes;
}
else
{
	echo "not exit".$yes;
}
?>