<?php 
include 'conn.php';
if(isset($_POST['submit']))
{ 
$name =$_POST['name'];
$fname =$_POST['fathername'];
$username =$_POST['username'];
$password =$_POST['password'];
$email =$_POST['email'];
$address =$_POST['address'];
$gender =$_POST['gender'];
$fileName = $_FILES['image']['name'];
$fileType = $_FILES['image']['type'];
$fileSize = $_FILES['image']['size'];
$fileTmpLoc = $_FILES['image']['tmp_name'];
$fileStore = "uploads/".$fileName;
move_uploaded_file($fileTmpLoc,$fileStore);
$sql="insert into student(name,fathername,gender,username,password,email,address,image) values('$name','$fname','$gender','$username','$password','$email ','$address','$fileName')";
if($conn->query($sql)){
	echo "Record has been inserted successfull!";
	header("Location:student.php");
}
#if($conn->query($sql)){
#	echo "data has been insert successfully!";
# header("Location:display1.php");
#
}
if(isset($_GET['delete']))
{
	$id =$_GET['delete'];
	$sql ="delete from student where id=$id";
	$result = $conn->query($sql);
	if($result)
	{
		header("Location:student.php");
}
	}
?>