<?php 
include 'conn.php';
if(isset($_POST['update1']))
{

 $id =$_POST['id'];
 $name =$_POST['name'];
$fname =$_POST['fathername'];
 $username =$_POST['username'];
 $password =$_POST['password'];
 $email =$_POST['email'];
 $address =$_POST['address'];
 $gender =$_POST['gender'];
$fileName = $_FILES['image']['name'];
$fileType = $_FILES['image']['type'];
$fileSize = $_FILES['image']['size'];
$fileTmpLoc = $_FILES['image']['tmp_name'];
$fileStore = "uploads/".$fileName;
move_uploaded_file($fileTmpLoc,$fileStore);
$sql ="update student set id=$id,name='$name',fathername='$fname',gender='$gender',username='$username',password='$password',email='$email',address='$address',image='$fileName' where id=$id";
#,image='$fileName'
if($conn->query($sql))
{
	header("Location:student.php");
}
else
{
	echo("error accur");
}
}

 ?>