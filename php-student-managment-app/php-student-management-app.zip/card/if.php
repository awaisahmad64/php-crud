<?php 

$name="awai";
if($name !="awais")
{
	echo "Please Enter correct name";
}
else {
	echo "please enter correct password";
}


 ?>