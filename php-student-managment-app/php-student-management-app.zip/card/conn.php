<?php 
$serverName ="localhost";
$userName = "root";
$password ="";
$mydb ="MinSchool";
$conn = new mysqli($serverName, $userName, $password, $mydb);
if(!$conn){
	die("connection failed".$conn->connect_error);
}
 ?>
