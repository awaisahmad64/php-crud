<?php 
include 'conn.php';
$sql = "select count(id) from student";
$result = $conn->query($sql);
$row =$result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Management System | Dashboad</title>
	<link rel="stylesheet" href="custom.css">
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="font/all.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="icheck-bootstrap/icheck-bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="bs-custom-file-input/bs-custom-file-input.min.js"></script>
</head>
<body>
	<header>
		<div class="user-name float-right mt-2 pr-2">
				<h6><img src="awais.jpg" class="rounded-circle ml-2" height="50px" width="50px"> Awais Sandhu</h6>
			</div>
	</header>
	<section>
		<nav>
			<div class="brand-name">
				<h4 class="text-white text-center">Webx Solutions</h4>
			</div>
			<div class="user-name">
				<h6><img src="awais.jpg" class="rounded-circle ml-2" height="50px" width="50px"> Awais Sandhu</h6>
			</div>
			<ul>
				<li class="nav-item"><a href="dashboard.php" class="nav-link"><i class="fas fa-th mr-2"></i>DashBoard</a></li>
				<li class="nav-item"><a href="student.php" class="nav-link"> <i class="fas fa-users mr-2"></i>Students</a></li>
				<li class="nav-item"><a href="teacher.php" class="nav-link"><i class="fas fa-user-tie mr-2"></i>Teachers</a></li>
				<li class="nav-item"><a href="#" class="nav-link"><i class="fas fa-book-reader mr-2"></i>Courses</a></li>
				<li class="nav-item"><a href="index.php" class="nav-link"><i class="fas fa-sign-out-alt mr-2"></i>Logout</a></li>
			</ul>
		</nav>
		<aside>
			<div class="header">
			</div>
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="container-fluid">
          <div class="col-md-6">
            
          </div>
        </div>
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Dashborad</h3>
          </div>
          <form role="form">
            <div class="card-body">
            <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3 class="text-center text-white pt-4"><?php echo $row['count(id)']; ?></h3>

                <h2 class="text-center text-white pb-4">Students</h2>
              </div>
              <div class="icon">
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
               <h3 class="text-center text-white pt-4">5</h3>

                <h2 class="text-center text-white pb-4">Teachers</h2>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3 class="text-center text-white pt-4">4</h3>

                <h2 class="text-center text-white pb-4">Courses</h2>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3 class="text-center text-white pt-4 ">14</h3>

                <h2 class="text-center text-white pb-4">Employees</h2>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
            </div>
          </div>
        
      </div>
    </div>
  </div>
		</aside>
	</section>
</body>
</html>