<?php 
if (isset($_POST['submit'])) {
	$name = $_POST['name'];
	$password = $_POST['pwd'];
	echo $name."<br>";
	echo $password;
}

 ?>