<!DOCTYPE html>
<html>
<head>
	<title>Student Management System | Dashboad</title>
	<link rel="stylesheet" href="custom.css">
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="font/all.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="icheck-bootstrap/icheck-bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="bs-custom-file-input/bs-custom-file-input.min.js"></script>
</head>
<body>
	<header>
		<div class="user-name float-right mt-2 pr-2">
				<h6><img src="awais.jpg" class="rounded-circle ml-2" height="50px" width="50px"> Awais Sandhu</h6>
			</div>
	</header>
	<section>
		<nav>
			<div class="brand-name">
				<h4 class="text-white text-center">Webx Solutions</h4>
			</div>
			<div class="user-name">
				<h6><img src="awais.jpg" class="rounded-circle ml-2" height="50px" width="50px"> Awais Sandhu</h6>
			</div>
			<ul>
        <li><a href="dashboard.php"><i class="fas fa-th mr-2"></i>DashBoard</a></li>
        <li><a href="student.php"> <i class="fas fa-users mr-2"></i>Students</a></li>
        <li><a href="teacher.php"><i class="fas fa-user-tie mr-2"></i>Teachers</a></li>
        <li><a href="#"><i class="fas fa-book-reader mr-2"></i>Courses</a></li>
      </ul>
		</nav>
		<aside>
			<div class="header">
			</div>
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <a href="addteacher.php" class="btn btn-primary my-2" id="bg-custom"><i class="fas fa-plus mr-2"></i></i>Add Teacher</a>
        <div class="card card-primary">
          <div class="card-header" id="bg-custom">
            <h3 class="card-title text-white">Teachers</h3>
          </div>
            <div class="card-body">
            <div class="row">
          <div class="col-lg-3 col-6">
               <table class="table table-bordered table-sm">
                   <thead>
                     <tr>
                       <th>Sr No.</th>
                       <th>Name</th>
                       <th>Father Name</th>
                        <th>UserName</th>
                       <th>Password</th>
                       <th>Email</th>
                        <th>Gender</th>
                       <th>Address</th>
                       <th>Photo</th>
                       <th>Actions</th>
                     </tr>
                   </thead>
                   <tbody>
                     <tr>
                        <td>1</td>
                       <td>Awais Ahmad</td>
                       <td>Fazal karim</td>
                        <td>Sandhu</td>
                       <td>12345</td>
                       <td>awais6412l@gmail.com</td>
                        <td>Male</td>
                       <td>64/12.L Chichawatni,Sahiwal</td>
                       <td>Photo</td>
                       <td><a href="#"><i class="fas fa-eye text-success mx-1" title="View Student Record"></i></a><a href="#"><i class="fas fa-edit mx-1 text-primary" title="Edit Student Record"></i></a><a href="#"><i class="fas fa-trash-alt text-danger mx-1" title="Delete Student Record"></i></a></td>
                     </tr>
                   </tbody>
                </table>
        
      </div>
    </div>
  </div>
		</aside>
	</section>
</body>
</html>